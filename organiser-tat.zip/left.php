<div id="left">
	<p>Add</p>
	<p>Show</p>
	<p></p>
	<p></p>
</div>