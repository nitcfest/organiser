<?php
session_start();
session_destroy();
echo "<a href='tat_login.php'>Log in</a>";
?>