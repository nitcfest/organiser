<?php

$host = 'localhost';
$db_name = 'tathva13';
$db_user = 'root';
$db_password = '';
$start_page = 'login.php';
$pr_page = 'proofreader.php';
$mk_page = 'kash.php';
$mn_page = 'manager.php';
$ad_page = 'terminal.php';
$u_ad="admin";
$p_ad="12tathva12";
$ml_page = 'mail.php';
$u_ml="mailer";
$p_ml="tmailer";
$cl_page = 'cl.php';
$u_cl="colleges";
$p_cl="clist";
$pl_page = 'pl.php';
$u_pl="publicity";
$p_pl="tpub";
?>
